#include "BSortTree.h"

int main() {
	BSortTree tree;
	return 0;
}