#include "ExamineeList.h"

int main() {	
	ExamineeList list;
	return 0;
}