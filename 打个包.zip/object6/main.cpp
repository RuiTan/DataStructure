#include "Family.h"

int main() {
	Family family();
	return 0;
}