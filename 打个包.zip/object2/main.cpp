#include "Josepth.h"

int main() {
	Josepth();
	return 0;
}