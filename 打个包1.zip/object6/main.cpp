#include "Family.h"

int main() {
	Family* family = new Family();
	system("pause");
	return 0;
}