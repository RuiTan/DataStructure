#include "Sorts.h"

int main() {
	Sorts sorts;
	return 0;
}