#include "Maze.h"

int main() {
	Maze maze;
	return 0;
}